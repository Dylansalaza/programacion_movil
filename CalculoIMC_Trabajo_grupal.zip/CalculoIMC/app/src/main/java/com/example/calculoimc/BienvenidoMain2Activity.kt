package com.example.calculoimc

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BienvenidoMain2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bienvenido_main2)

        // Recupera el nombre enviado desde la actividad anterior
        val nombre = intent.getStringExtra("nombre") ?: "Usuario"

        // Referencia al TextView para mostrar el mensaje
        val tvSaludo: TextView = findViewById(R.id.tvSaludo)

        // Establece el saludo con el nombre del usuario
        tvSaludo.text = "¡Bienvenido, $nombre!"

        // Transición a la siguiente actividad después de 3 segundos
        Handler(mainLooper).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 3000)
    }
}