package com.example.calculoimc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class InicioMain2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.inicio_main2)

        // Configuración de márgenes para la barra de estado y navegación
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referencias a los elementos de la vista
        val etNombre: EditText = findViewById(R.id.etNombre)
        val bSaludar: Button = findViewById(R.id.bSaludar)

        // Configuración de la acción del botón
        bSaludar.setOnClickListener {
            val nombre = etNombre.text.toString().trim() // Capturamos el texto del usuario

            if (nombre.isNotEmpty()) {
                // Si el campo no está vacío, pasamos a la actividad de bienvenida
                val intent = Intent(this, BienvenidoMain2Activity::class.java)
                intent.putExtra("nombre", nombre) // Enviamos el nombre como extra
                startActivity(intent) // Iniciamos la actividad
            } else {
                // Mostramos un mensaje si el campo está vacío
                Toast.makeText(this, "Por favor, ingresa tu nombre.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}