package com.example.calculoimc



import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private var isMale = true
    private var weight = 60
    private var height = 170

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnMujer = findViewById<Button>(R.id.btnMujer)
        val btnHombre = findViewById<Button>(R.id.btnHombre)
        val seekPeso = findViewById<SeekBar>(R.id.seekPeso)
        val seekAltura = findViewById<SeekBar>(R.id.seekAltura)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)
        val txtPeso = findViewById<TextView>(R.id.txtPeso)
        val txtAltura = findViewById<TextView>(R.id.txtAltura)

        // Inicializar valores en TextView
        txtPeso.text = "Peso: $weight kg"
        txtAltura.text = "Altura: $height cm"

        btnMujer.setOnClickListener {
            isMale = false
            btnMujer.setBackgroundColor(ContextCompat.getColor(this, R.color.teal_700))
            btnHombre.setBackgroundColor(ContextCompat.getColor(this, R.color.purple_500))
        }

        btnHombre.setOnClickListener {
            isMale = true
            btnHombre.setBackgroundColor(ContextCompat.getColor(this, R.color.teal_700))
            btnMujer.setBackgroundColor(ContextCompat.getColor(this, R.color.purple_500))
        }

        seekPeso.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                weight = progress
                txtPeso.text = "Peso: $weight kg"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekAltura.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                height = progress
                txtAltura.text = "Altura: $height cm"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnCalcular.setOnClickListener {
            val alturaMetros = height / 100.0
            val imc = weight / (alturaMetros * alturaMetros)

            val pesoIdeal = if (isMale) {
                50 + 0.91 * (height - 152.4)
            } else {
                45.5 + 0.91 * (height - 152.4)
            }

            val categoriaIMC = obtenerCategoriaIMC(imc)

            txtResultado.text = "Peso Ideal: %.2f kg\nIMC: %.2f\nCategoría: %s".format(pesoIdeal, imc, categoriaIMC)
            Toast.makeText(this, "Cálculo realizado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun obtenerCategoriaIMC(imc: Double): String {
        return when {
            imc < 18.5 -> "Bajo peso"
            imc in 18.5..24.9 -> "peso normal"
            imc in 25.0..26.9 -> "Sobrepeso grado I"
            imc in 27.0..29.9 -> "Sobrepeso grado II"
            imc in 30.0..34.9 -> "Obesidad de tipo I"
            imc in 35.0..39.9 -> "Obesidad de tipo II"
            imc in 40.0..49.9 -> "Obesidad de tipo III (mórbida)"
            else -> "Obesidad de tipo IV (extrema)"
        }
    }
}
