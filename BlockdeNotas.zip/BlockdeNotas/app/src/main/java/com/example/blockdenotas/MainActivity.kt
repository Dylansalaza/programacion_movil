package com.example.blockdenotas

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var fabAddNote: FloatingActionButton
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configurar barra de estado
        window.statusBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        recyclerView = findViewById(R.id.recyclerView)
        fabAddNote = findViewById(R.id.fabAddNote)
        dbHelper = DatabaseHelper(this)

        // Configurar RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        loadNotes()

        // Configurar botón de agregar
        fabAddNote.setOnClickListener {
            val intent = Intent(this, NoteDetailActivity::class.java)
            startActivityForResult(intent, 1)
        }
    }

    private fun loadNotes() {
        val notes = dbHelper.getAllNotes()
        val adapter = NotesAdapter(notes) { note ->
            val intent = Intent(this, NoteDetailActivity::class.java).apply {
                putExtra("note_id", note.id)
            }
            startActivityForResult(intent, 1)
        }
        recyclerView.adapter = adapter
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            loadNotes()
        }
    }
}