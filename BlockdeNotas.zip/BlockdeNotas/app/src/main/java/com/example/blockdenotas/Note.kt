package com.example.blockdenotas

data class Note(
    val id: Long,
    val title: String,
    val content: String,
    val timestamp: Long
)