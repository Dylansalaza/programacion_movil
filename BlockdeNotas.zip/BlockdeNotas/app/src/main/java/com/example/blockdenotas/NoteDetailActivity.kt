package com.example.blockdenotas

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.*

class NoteDetailActivity : AppCompatActivity() {

    // Componentes de la interfaz
    private lateinit var etNoteTitle: EditText
    private lateinit var etNoteContent: EditText
    private lateinit var tvNoteInfo: TextView
    private lateinit var fabSave: FloatingActionButton

    // Base de datos
    private lateinit var dbHelper: DatabaseHelper
    private var noteId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_detail)

        // Inicializar vistas
        initViews()

        // Configurar base de datos
        dbHelper = DatabaseHelper(this)

        // Obtener ID de la nota (si es edición)
        noteId = intent.getLongExtra("note_id", -1L)

        // Cargar nota existente si hay ID
        if (noteId != -1L) {
            loadExistingNote()
        }

        // Configurar listeners
        setupListeners()
    }

    private fun initViews() {
        etNoteTitle = findViewById(R.id.etNoteTitle)
        etNoteContent = findViewById(R.id.etNoteContent)
        tvNoteInfo = findViewById(R.id.tvNoteInfo)
        fabSave = findViewById(R.id.fabSave)
    }

    private fun loadExistingNote() {
        dbHelper.getNoteById(noteId)?.let { note ->
            etNoteTitle.setText(note.title)
            etNoteContent.setText(note.content)
            updateCharacterCount()
        }
    }

    private fun setupListeners() {
        // Listener para el botón de guardar
        fabSave.setOnClickListener {
            saveNote()
            finish()
        }

        // Listener para el contador de caracteres
        etNoteContent.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = updateCharacterCount()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun saveNote() {
        val title = etNoteTitle.text.toString().trim()
        val content = etNoteContent.text.toString().trim()

        if (noteId == -1L) {
            // Nueva nota
            if (title.isNotEmpty() || content.isNotEmpty()) {
                dbHelper.insertNote(title, content)
            }
        } else {
            // Editar nota existente
            dbHelper.updateNote(noteId, title, content)
        }
    }

    private fun updateCharacterCount() {
        val charCount = etNoteContent.text.length
        val currentDate = SimpleDateFormat("d MMMM HH:mm", Locale.getDefault()).format(Date())
        tvNoteInfo.text = "$currentDate | $charCount caracteres"
    }

    override fun onBackPressed() {
        saveNote()
        super.onBackPressed()
    }
}