package com.example.recordatorio;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null && intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            // Restaurar todas las alarmas
            DatabaseHelper dbHelper = new DatabaseHelper(context);
            List<Medicine> medicines = dbHelper.getAllMedicines();
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            for (Medicine medicine : medicines) {
                Intent alarmIntent = new Intent(context, AlarmReceiver.class);
                alarmIntent.putExtra("MEDICINE_NAME", medicine.getName());
                alarmIntent.putExtra("MEDICINE_DOSAGE", medicine.getDosage());

                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        context,
                        (int) medicine.getId(),
                        alarmIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, medicine.getHour());
                calendar.set(Calendar.MINUTE, medicine.getMinute());
                calendar.set(Calendar.SECOND, 0);

                // Si la hora ya pasó hoy, programar para mañana
                if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
                    calendar.add(Calendar.DAY_OF_MONTH, 1);
                }

                // Programar alarma
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(
                                AlarmManager.RTC_WAKEUP,
                                calendar.getTimeInMillis(),
                                pendingIntent
                        );
                    }
                } else {
                    alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            calendar.getTimeInMillis(),
                            pendingIntent
                    );
                }
            }
        }
    }
}