package com.example.recordatorio;

public class Medicine {
    private long id;
    private String name;
    private String dosage;
    private int hour;
    private int minute;

    public Medicine(long id, String name, String dosage, int hour, int minute) {
        this.id = id;
        this.name = name;
        this.dosage = dosage;
        this.hour = hour;
        this.minute = minute;
    }

    // Getters
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDosage() {
        return dosage;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    // Setters
    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }
}