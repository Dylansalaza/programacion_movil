package com.example.recordatorio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Nombre y versión de la base de datos
    private static final String DATABASE_NAME = "MedicinesDB";
    private static final int DATABASE_VERSION = 1;

    // Constantes para la tabla y columnas
    public static final String TABLE_MEDICINES = "medicines";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_DOSAGE = "dosage";
    public static final String COLUMN_HOUR = "hour";
    public static final String COLUMN_MINUTE = "minute";

    // Sentencia SQL para crear la tabla
    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_MEDICINES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT NOT NULL, " +
                    COLUMN_DOSAGE + " TEXT NOT NULL, " +
                    COLUMN_HOUR + " INTEGER NOT NULL, " +
                    COLUMN_MINUTE + " INTEGER NOT NULL)";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // En caso de actualización, eliminar la tabla anterior y crear una nueva
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEDICINES);
        onCreate(db);
    }

    // Método para insertar un nuevo medicamento
    public long insertMedicine(String name, String dosage, int hour, int minute) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DOSAGE, dosage);
        values.put(COLUMN_HOUR, hour);
        values.put(COLUMN_MINUTE, minute);

        // Insertar y obtener el ID generado
        long id = db.insert(TABLE_MEDICINES, null, values);
        db.close();
        return id;
    }

    // Método para obtener todos los medicamentos
    public List<Medicine> getAllMedicines() {
        List<Medicine> medicineList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_MEDICINES + " ORDER BY " + COLUMN_HOUR + ", " + COLUMN_MINUTE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                String dosage = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DOSAGE));
                int hour = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HOUR));
                int minute = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MINUTE));

                Medicine medicine = new Medicine(id, name, dosage, hour, minute);
                medicineList.add(medicine);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return medicineList;
    }

    // Método para actualizar un medicamento
    public int updateMedicine(long id, String name, String dosage, int hour, int minute) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DOSAGE, dosage);
        values.put(COLUMN_HOUR, hour);
        values.put(COLUMN_MINUTE, minute);

        int rowsAffected = db.update(TABLE_MEDICINES, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return rowsAffected;
    }

    // Método para eliminar un medicamento por su ID
    public void deleteMedicine(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_MEDICINES, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}