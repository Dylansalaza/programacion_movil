package com.example.recordatorio

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MedicineAdapter
    private lateinit var medicineList: MutableList<Medicine>
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var emptyView: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar componentes
        recyclerView = findViewById(R.id.recyclerView)
        val fabAdd: FloatingActionButton = findViewById(R.id.fabAdd)
        emptyView = findViewById(R.id.emptyView)

        // Inicializar base de datos
        dbHelper = DatabaseHelper(this)

        // Inicializar lista y adaptador
        medicineList = mutableListOf()
        adapter = MedicineAdapter()

        // Configurar RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Cargar datos
        loadMedicines()

        // Configurar botón de agregar
        fabAdd.setOnClickListener { showAddMedicineDialog() }
    }

    override fun onResume() {
        super.onResume()
        loadMedicines() // Recargar datos cuando se regresa a la actividad
    }

    private fun loadMedicines() {
        medicineList = dbHelper.getAllMedicines().toMutableList()
        adapter.setMedicines(medicineList)

        // Mostrar vista vacía si no hay medicamentos
        if (medicineList.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun showAddMedicineDialog() {
        val builder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.dialog_add_medicine, null)
        builder.setView(view)

        val etName: EditText = view.findViewById(R.id.etMedicineName)
        val etDosage: EditText = view.findViewById(R.id.etDosage)
        val tvTime: TextView = view.findViewById(R.id.tvTime)
        val btnSetTime: Button = view.findViewById(R.id.btnSetTime)
        val btnSave: Button = view.findViewById(R.id.btnSave)
        val btnCancel: Button = view.findViewById(R.id.btnCancel)

        // Valores iniciales para la hora
        val calendar = Calendar.getInstance()
        var hour = calendar.get(Calendar.HOUR_OF_DAY)
        var minute = calendar.get(Calendar.MINUTE)

        // Mostrar tiempo inicial
        tvTime.text = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)

        // Configurar selector de tiempo
        btnSetTime.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hourOfDay, minuteOfDay ->
                    hour = hourOfDay
                    minute = minuteOfDay
                    tvTime.text = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
                },
                hour,
                minute,
                true
            ).show()
        }

        val dialog = builder.create()

        // Guardar medicamento
        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val dosage = etDosage.text.toString().trim()

            if (name.isEmpty() || dosage.isEmpty()) {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Insertar en la base de datos
            val id = dbHelper.insertMedicine(name, dosage, hour, minute)

            if (id != -1L) {
                // Programar alarma
                scheduleAlarm(Medicine(id, name, dosage, hour, minute))
                loadMedicines() // Recargar lista
                Toast.makeText(this, "Medicamento guardado", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun scheduleAlarm(medicine: Medicine) {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra("MEDICINE_NAME", medicine.name)
            putExtra("MEDICINE_DOSAGE", medicine.dosage)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            medicine.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, medicine.hour)
            set(Calendar.MINUTE, medicine.minute)
            set(Calendar.SECOND, 0)

            // Si la hora ya pasó hoy, programar para mañana
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        // Programar alarma
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                Toast.makeText(this, "Se requiere permiso para programar alarmas exactas", Toast.LENGTH_LONG).show()
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        }
    }

    // Adaptador para la lista de medicamentos
    private inner class MedicineAdapter : RecyclerView.Adapter<MedicineAdapter.ViewHolder>() {
        private var medicines: List<Medicine> = listOf()

        fun setMedicines(medicines: List<Medicine>) {
            this.medicines = medicines
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_medicine, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val medicine = medicines[position]
            holder.tvName.text = medicine.name
            holder.tvDosage.text = medicine.dosage
            holder.tvTime.text = String.format(Locale.getDefault(),
                "%02d:%02d", medicine.hour, medicine.minute)

            holder.btnDelete.setOnClickListener {
                // Cancelar alarma
                val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
                val intent = Intent(this@MainActivity, AlarmReceiver::class.java)
                val pendingIntent = PendingIntent.getBroadcast(
                    this@MainActivity,
                    medicine.id.toInt(),
                    intent,
                    PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.cancel(pendingIntent)

                // Eliminar de la base de datos
                dbHelper.deleteMedicine(medicine.id)

                // Recargar lista
                loadMedicines()
            }
        }

        override fun getItemCount(): Int = medicines.size

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvName: TextView = itemView.findViewById(R.id.tvMedicineName)
            val tvDosage: TextView = itemView.findViewById(R.id.tvDosage)
            val tvTime: TextView = itemView.findViewById(R.id.tvTime)
            val btnDelete: Button = itemView.findViewById(R.id.btnDelete)
        }
    }
}