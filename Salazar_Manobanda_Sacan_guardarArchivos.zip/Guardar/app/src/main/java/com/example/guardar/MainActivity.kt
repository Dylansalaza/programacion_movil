package com.example.guardar

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

class MainActivity : AppCompatActivity() {
    var listaDatos: MutableList<Contactos> = ArrayList()
    var listaNombres: MutableList<String> = ArrayList()
    private lateinit var bGuardar: Button
    private lateinit var bLeer: Button
    private lateinit var bMostrar: Button
    private lateinit var bEditar: Button
    private lateinit var bEliminar: Button
    private lateinit var eTNombre: EditText
    private lateinit var eTTelefono: EditText
    private lateinit var eTEdad: EditText
    private lateinit var lstNombres: Spinner
    private var editMode = false
    private var currentIndex = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize UI elements
        eTNombre = findViewById(R.id.eTNombre)
        eTTelefono = findViewById(R.id.eTTelefono)
        eTEdad = findViewById(R.id.eTEdad)
        lstNombres = findViewById(R.id.lstNombres)

        bGuardar = findViewById(R.id.bGuardar)
        bGuardar.setOnClickListener {
            if (editMode) {
                editarContacto()
            } else {
                guardarEnLista()
            }
            guardarDatos()
        }

        bLeer = findViewById(R.id.bLeer)
        bLeer.setOnClickListener {
            leeDelArchivo()
        }

        bMostrar = findViewById(R.id.bMostrar)
        bMostrar.setOnClickListener {
            muestraDatos()
        }

        bEditar = findViewById(R.id.bEditar)
        bEditar.setOnClickListener {
            cargarDatosParaEditar()
        }

        bEliminar = findViewById(R.id.bEliminar)
        bEliminar.setOnClickListener {
            eliminarContacto()
        }
    }

    fun guardarDatos() {
        val ruta = applicationContext.filesDir
        val nombreArch = "archivo.dts"

        try {
            val escribirArch = FileOutputStream(File(ruta, nombreArch))
            val streamArch = ObjectOutputStream(escribirArch)
            streamArch.writeObject(listaDatos)
            streamArch.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun guardarEnLista() {
        if (eTNombre.text.toString().isNotEmpty() &&
            eTTelefono.text.toString().isNotEmpty() &&
            eTEdad.text.toString().isNotEmpty()) {

            listaDatos.add(
                Contactos(
                    eTNombre.text.toString(),
                    eTTelefono.text.toString(),
                    eTEdad.text.toString().toInt()
                )
            )
            Toast.makeText(this, "Contacto Agregado", Toast.LENGTH_SHORT).show()
            limpiarCampos()
        } else {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
        }
    }

    fun limpiarCampos() {
        eTNombre.setText("")
        eTTelefono.setText("")
        eTEdad.setText("")
        editMode = false
        currentIndex = -1
        bGuardar.text = "Guardar"
    }

    fun leeDelArchivo() {
        // El objeto File con la ruta donde almacenarlo
        val ruta = applicationContext.filesDir
        // Éste es el nombre del archivo
        val nombreArch = "archivo.dts"

        // Borro la lista y borro lo que está en el spinner (el adapter será el arreglo vacío)
        listaNombres.clear()
        var llenaSpinner = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item, listaNombres
        )
        lstNombres.adapter = llenaSpinner

        // Leo los datos del archivo
        try {
            // FileInputStream me permite abri el archivo para leer de él
            val leeArch = FileInputStream(File(ruta, nombreArch))
            // El ObjectInputStream me pemite traducir el arreglo de bytes al Arraylist
            val streamArch = ObjectInputStream(leeArch)
            // Leo todo y lleno la lista
            listaDatos = streamArch.readObject() as ArrayList<Contactos>
            // Cierro el stream
            streamArch.close()

            // Lleno la lista de nombres (strings) con los nombres de la lista de datos
            listaNombres.clear()
            for (i in listaDatos.indices) {
                listaNombres.add(listaDatos[i].getNombre())
            }
            // Lleno el Spinner de la nueva lista
            llenaSpinner = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item, listaNombres
            )
            llenaSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            lstNombres.adapter = llenaSpinner
        } catch (e: Exception) {
            e.printStackTrace() // Si hay error, que muestre datos sobre el fallo
        }
    }

    fun muestraDatos() {
        // Creo un Alert Builder (ventana estándar que puedo usar)
        val constructor = AlertDialog.Builder(this)
        constructor.setTitle("Almacena") // Pongo título a la ventana
        constructor.setPositiveButton("Aceptar", null) // Agrego un botón

        // Si se seleccionó algo en el spinner, le sigo
        val index = lstNombres.selectedItemPosition
        if (index > -1 && index < listaDatos.size) {
            // Pongo mensaje a la ventana que voy a mostrar
            constructor.setMessage(
                "Nombre: ${listaDatos[index].getNombre()}\n" +
                        "Teléfono: ${listaDatos[index].getTelefono()}\n" +
                        "Edad: ${listaDatos[index].getEdad()}"
            )
        } else {
            constructor.setMessage("Debe seleccionar un nombre de la lista")
        }

        // Creo y muestro la ventana
        val ventanaMensaje = constructor.create()
        ventanaMensaje.show()
    }

    fun cargarDatosParaEditar() {
        val index = lstNombres.selectedItemPosition
        if (index > -1 && index < listaDatos.size) {
            // Cargar datos en los campos de texto
            eTNombre.setText(listaDatos[index].getNombre())
            eTTelefono.setText(listaDatos[index].getTelefono())
            eTEdad.setText(listaDatos[index].getEdad().toString())

            // Cambiar a modo edición
            editMode = true
            currentIndex = index
            bGuardar.text = "Actualizar"

            Toast.makeText(this, "Editando contacto: ${listaDatos[index].getNombre()}", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Seleccione un contacto para editar", Toast.LENGTH_SHORT).show()
        }
    }

    fun editarContacto() {
        if (currentIndex != -1 && currentIndex < listaDatos.size) {
            if (eTNombre.text.toString().isNotEmpty() &&
                eTTelefono.text.toString().isNotEmpty() &&
                eTEdad.text.toString().isNotEmpty()) {

                // Actualizar contacto existente
                listaDatos[currentIndex].setNombre(eTNombre.text.toString())
                listaDatos[currentIndex].setTelefono(eTTelefono.text.toString())
                listaDatos[currentIndex].setEdad(eTEdad.text.toString().toInt())

                Toast.makeText(this, "Contacto actualizado", Toast.LENGTH_SHORT).show()
                limpiarCampos()

                // Actualizar spinner
                leeDelArchivo()
            } else {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun eliminarContacto() {
        val index = lstNombres.selectedItemPosition
        if (index > -1 && index < listaDatos.size) {
            // Mostrar diálogo de confirmación
            val constructor = AlertDialog.Builder(this)
            constructor.setTitle("Vas a eliminar este Usuario")
            constructor.setMessage("¿Está seguro que desea eliminar a ${listaDatos[index].getNombre()}?")

            constructor.setPositiveButton("Sí") { _, _ ->
                // Eliminar contacto
                listaDatos.removeAt(index)
                guardarDatos()
                leeDelArchivo()
                Toast.makeText(this, "Contacto eliminado", Toast.LENGTH_SHORT).show()

                // Si estaba en modo edición y eliminó el contacto que estaba editando
                if (editMode && currentIndex == index) {
                    limpiarCampos()
                }
            }
            constructor.setNegativeButton("No", null)

            val ventanaConfirmacion = constructor.create()
            ventanaConfirmacion.show()
        } else {
            Toast.makeText(this, "Seleccione un contacto para eliminar", Toast.LENGTH_SHORT).show()
        }
    }
}