package com.example.sqluno

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class dbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "contactos.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        val crearTabla = """
            CREATE TABLE contactos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                telefono TEXT NOT NULL,
                direccion TEXT NOT NULL
            )
        """.trimIndent()
        db.execSQL(crearTabla)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS contactos")
        onCreate(db)
    }

    fun insertar(nombre: String, telefono: String, direccion: String): Long {
        val db = this.writableDatabase
        val datos = ContentValues().apply {
            put("nombre", nombre)
            put("telefono", telefono)
            put("direccion", direccion)
        }
        val resultado = db.insert("contactos", null, datos)
        db.close()
        return resultado
    }

    fun leer(): Cursor {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM contactos", null)
    }
}