package com.example.sqluno

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var txtNombre: EditText
    private lateinit var txtTelefono: EditText
    private lateinit var txtDireccion: EditText
    private lateinit var btnGuardarDisco: Button
    private lateinit var btnMostrarContactos: Button
    private lateinit var tablaContactos: TableLayout
    private lateinit var scrollTabla: ScrollView
    private lateinit var contactosHelper: dbHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initComponentes()

        btnGuardarDisco.setOnClickListener {
            guardarContacto()
        }

        btnMostrarContactos.setOnClickListener {
            toggleTablaContactos()
        }
    }

    private fun initComponentes() {
        txtNombre = findViewById(R.id.eTNombre)
        txtTelefono = findViewById(R.id.eTTelefono)
        txtDireccion = findViewById(R.id.eTDireccion)
        btnGuardarDisco = findViewById(R.id.btnGuardarDisco)
        btnMostrarContactos = findViewById(R.id.btnMostrarContactos)
        tablaContactos = findViewById(R.id.tablaContactos)
        scrollTabla = findViewById(R.id.scrollTabla)
        contactosHelper = dbHelper(this)
    }

    private fun guardarContacto() {
        val nombre = txtNombre.text.toString().trim()
        val telefono = txtTelefono.text.toString().trim()
        val direccion = txtDireccion.text.toString().trim()

        if (nombre.isEmpty() || telefono.isEmpty() || direccion.isEmpty()) {
            Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val resultado = contactosHelper.insertar(nombre, telefono, direccion)
        if (resultado != -1L) {
            Toast.makeText(this, "Contacto guardado", Toast.LENGTH_SHORT).show()
            limpiarCampos()
            // Ocultar tabla después de guardar
            scrollTabla.visibility = View.GONE
        } else {
            Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleTablaContactos() {
        if (scrollTabla.visibility == View.VISIBLE) {
            scrollTabla.visibility = View.GONE
        } else {
            mostrarContactos()
            scrollTabla.visibility = View.VISIBLE
        }
    }

    private fun mostrarContactos() {
        // Limpiar tabla antes de mostrar nuevos datos
        tablaContactos.removeAllViews()

        // Crear fila de encabezados
        val encabezado = TableRow(this).apply {
            addView(crearCelda("ID", true))
            addView(crearCelda("Nombre", true))
            addView(crearCelda("Teléfono", true))
            addView(crearCelda("Dirección", true))
        }
        tablaContactos.addView(encabezado)

        // Obtener y mostrar contactos
        val cursor = contactosHelper.leer()
        if (cursor.count == 0) {
            val filaVacia = TableRow(this).apply {
                addView(crearCelda("No hay contactos registrados", false, 4))
            }
            tablaContactos.addView(filaVacia)
        } else {
            while (cursor.moveToNext()) {
                val fila = TableRow(this).apply {
                    addView(crearCelda(cursor.getInt(0).toString()))
                    addView(crearCelda(cursor.getString(1)))
                    addView(crearCelda(cursor.getString(2)))
                    addView(crearCelda(cursor.getString(3)))
                }
                tablaContactos.addView(fila)
            }
        }
        cursor.close()
    }

    private fun crearCelda(texto: String, isHeader: Boolean = false, colSpan: Int = 1): TextView {
        return TextView(this).apply {
            text = texto
            setPadding(16, 16, 16, 16)
            gravity = Gravity.CENTER
            setTextColor(if (isHeader) Color.WHITE else Color.BLACK)
            setBackgroundColor(if (isHeader) Color.parseColor("#3F51B5") else Color.WHITE)

            val params = TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT
            )
            params.span = colSpan
            layoutParams = params
        }
    }

    private fun limpiarCampos() {
        txtNombre.text.clear()
        txtTelefono.text.clear()
        txtDireccion.text.clear()
        txtNombre.requestFocus()
    }
}